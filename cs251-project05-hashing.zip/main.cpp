/*main.cpp*/

//
// Hashing program for specialized Illinois license plates,
// which processes an input file of license plates and fines.
// The output is the total fines per license plate, in 
// sorted order.
//
// Original author: Prof. Joe Hummel
// Modified by:     John D. McDonald
//
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cassert>

#include "ILplates.h"

using namespace std;

struct keyValueStruct
{
	string plate;
	int fine;
};

// hashInput:
void hashInput(string basename, ILplates& hashplates)
{
  string infilename = basename + ".txt";
  ifstream infile(infilename);

  if (!infile.good())
  {
    cout << endl;
    cout << "**Error: unable to open input file '" << infilename << "', exiting." << endl;
    cout << endl;
    exit(-1);
  }
	
  // input the plates and fines:
  cout << "Reading '" << infilename << "'..." << endl;

  string fine;
  string plate;

  getline(infile, fine);
 
  //
  // for each pair (fine, license plate), hash and store/update fine:
  //
  while (!infile.eof())
  {
    getline(infile, plate);

	// Debugging Only:
    //cout << fine << endl;
    //cout << plate << endl;
	
    // is plate valid?  Only process valid plates:
    if (hashplates.Hash(plate) >= 0)  // yes:
    {
      int amount = hashplates.Search(plate);

      if (amount < 0)  // not found:
      {
        hashplates.Insert(plate, stoi(fine));
      }
      else  // we found it, so update total in hash table:
      {
        amount += stoi(fine);
        hashplates.Insert(plate, amount);
      }

    }//valid
    
    getline(infile, fine);
  }
   
}

void sortFunction (vector <keyValueStruct> &vectorOfStructs, vector<string> &plateVector, vector<int> &fineVector) 
{
	unsigned int i;		
	keyValueStruct temp;
	
	// Modifies vectorOfStructs to Store 
	// Unsorted Structs of Key Value Pairs
	for (i = 0; i < plateVector.size(); ++i) 
	{
		temp.plate = plateVector.at(i);
		temp.fine = fineVector.at(i);
	
		vectorOfStructs.push_back(temp);
	}
	
	// Sort the vectorOfStructs
	// I Used Selection Sort
	
	unsigned int j;
	unsigned int n;
	unsigned int min_index;
	
	n = vectorOfStructs.size();
	
	for (i = 0; i < (n-1); i++) 
	{
		// Find the Minimum Element in the Unsorted Vector
		min_index = i;
		
		for (j = i + 1; j < n; j++){
			if (vectorOfStructs.at(j).plate < vectorOfStructs.at(min_index).plate) 
			{
				min_index = j;			
			}
			// Swap the Minimum Element with the Element at Min_Index	
			
		} // End of Nested Loop
		temp = vectorOfStructs.at(min_index);
		vectorOfStructs.at(min_index) = vectorOfStructs.at(i);
		vectorOfStructs.at(i) = temp;
	} // End of Outer For Loop
	
	return;
}

void writeOutput (vector <keyValueStruct> &vectorofStructs, string fileName) {
	
	string plate;    // Stores the license plate number
	int amount;      // Stores the Fine Amount
	
	fileName = fileName + "-output.txt";
	
	ofstream outfile(fileName);
	
	for (unsigned i = 0; i < vectorofStructs.size(); ++i) 
	{
		plate = vectorofStructs.at(i).plate;
		amount = vectorofStructs.at(i).fine;
		
		outfile << "\"" << plate << "\"" << " $" << amount << endl; // Write One Line to Output File
		
	}// End of For Loop

	return;
}

int main()
{
  int    N;        // = 10000;
  string basename; // = "tickets1";
	
  cout << "Enter hashtable size> ";
  cin >> N;

  hashtable<string, int>  ht(N);
  ILplates                hashplates(ht);

  cout << "Enter base filename> ";
  cin >> basename;
  cout << endl;	

  // process input file of fines and license plates:
  hashInput(basename, hashplates);
  	
  // sort the key-value pairs by platename (i.e., key)
  cout << "Sorting..." << endl;
  vector <keyValueStruct> vectorOfStructs;
  vector<string> plates = ht.Keys();
  vector<int> fines = ht.Values();
  
  sortFunction(vectorOfStructs, plates, fines); 
	
  // Write the Sorted Output to an Output Text File
  cout << "writing '" << basename << "-output.txt'" << "..." << endl;

  writeOutput (vectorOfStructs, basename);  // This is the Graded Output
 
  // For Debugging Purposes Only
  ofstream outfile("Test.txt");
 
  for (unsigned i = 0; i < vectorOfStructs.size(); ++i) 
  {
		string plate = vectorOfStructs.at(i).plate;
	    int hash = hashplates.Hash(plate);
		
		outfile << plate << " " << hash << " " << " " << hash%N << endl; // Write One Line to Output File
		
  }// End of For Loop	

	
  return 0;
}