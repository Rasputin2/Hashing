/*ILplates.cpp*/

//
// Hashing functions to store (license plate, amount) pairs
// using linear probing.
//
// John D. McDonald
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <string>
#include <ctype.h>
#include <stdlib.h>
#include <cmath>

#include "ILplates.h"

using namespace std;

// isValid Function:
// Tests Whether the Plate is a Valid PlateName
bool isValid (string plate) 
{
	bool valid;
	unsigned int  i;
	unsigned int  numSpaces;
	unsigned int  numLetters;
	unsigned int  numDigits;
	bool firstChar;
	char tempChar;
	
	numLetters = 0;
	numSpaces = 0;
	numDigits = 0;
	valid = false;
	firstChar = false;
	
	// Test Total Size: Check Size
	// Reject if Too Big
    if ((plate.length() > 8) || (plate.length() < 0)) 
	{
		//cout << "Plate Name Too Large or Less than Zero" << endl;
		return valid;
	}	
	
	// Check Spaces:
	
	// Returns False if First Char is Spaces
	if (plate.at(0)== ' ') {
		
		return valid;
		
	}
	
	// Returns False if More than One Space
	for (i=0; i < plate.size(); ++i) 
	{
		tempChar = plate.at(i);
		
		if(tempChar == ' ') 
		{
			numSpaces = numSpaces + 1;
		}
		
		if (numSpaces > 1) 
		{
			//cout << "Too many spaces" << endl;
			return valid;
		}
	}  
	
	// Metrics for Additional Testing
	
	// Check Num Letters and Num Digits
	// If there are more than 3 Digits Return False
	for (i = 0; i < plate.size(); ++i) 
	{
		if (isupper(plate.at(i))) {
			numLetters = numLetters + 1;
		}
		
		if (isdigit(plate.at(i))) {
			numDigits = numDigits + 1;
		}
		
		// If there are more than 3 digits return false
		if (numDigits > 3) {
			return valid;
		}
		
	} // End Num Letters and Num Digits		
				
	// Read First Char
	// Use to Determine Further Testing
	tempChar = plate.at(0);
	if (isupper(tempChar)) 
	{
		firstChar = true;
	}
	
	// Scenario One: First Character is Digits
	// That Means All Characters Must be Digits
	// There Must be No More than Three Digits	
	if (!firstChar) 
	{
		// If Plate > 3 Digits Return False
		if (plate.size() > 3) {
			//cout << "Plate Size > 3 Digits" << endl;
			return valid;
		} // End if
		
		// If The Three Chars are not all Digits Return False
		for (i = 0; i < plate.size(); ++i)
		{
		    tempChar = plate.at(i);
			
			if (!isdigit(tempChar)){
				//cout << "Plate starting with Digits <> Contain ALL Digits" << endl;
				return valid;
			} // End Nested if
			
		}// End For		
		
		valid = true;
		return valid; 
	} // End Scenario One
	
	// Scenario Two:
	// All UPPERCASE Letters
	unsigned int numLtrs = 0;
	
	if ((numDigits < 1) && (numSpaces < 1)) {
		for (i = 0; i < plate.size(); ++i) 
		{
			if (isupper(plate.at(i))) 
			{
				numLtrs = numLtrs + 1;
			}
			
			if ((plate.size()) < 8 && (numLtrs == plate.size())) 
			{
				valid = true;
				return true;
			}			
		} 
	} // End Scenario Two
	
	// Scenario 3: 6 letters and 1 Digit
	if ((numLetters == 6) and (numDigits == 1)) 
	{
		for (i = 0; i < 6; ++i) {
			tempChar = plate.at(i);
			if (!isupper(tempChar)){
				//cout << "6 Letters 1 Digit, but First Elements not Letters" << endl;
				return valid; 
			}
		}
		
		if (plate.at(6) != ' ') {
			//cout << "6 Letters 1 Digit, but Space is not in Correct Position" << endl;
			return valid;
		}
		
		// If the first six digits are letters, there is a space and 1 digit
		// then it is a valid plate
		valid = true; 
		return valid;
	} 
	
	// Scenario 4:
	// There Must Be No More than 5 Digits and no More than 2 Digits
	if (numLetters > 5) 
	{
		//cout << "Scenario 4: More than 5 Letters." << endl;
		return valid;
	}
	
	if (numLetters < 1) 
	{
		//cout << "Scenario 4: Less than 1 Letter." << endl;
		return valid;
	}
	
	if (numDigits > 2) 
	{
		//cout << "Scenario 4: More than 2 Digits" << endl;
		return valid;
	}
	
	if (numDigits < 1) 
	{
		//cout << "Scenario 4: Less than 1 Digits" << endl;
		return valid;
	}
	
	for (i = 0; i < numLetters; ++i) 
	{
		tempChar = plate.at(i);
		if (!isupper(tempChar)) {
			//cout << "Scenario 4: The first characters were not all letters" << endl;
			return valid;
		}
	}
	
	tempChar = plate.at(numLetters);
	
	if (tempChar != ' ') 
	{
		//cout << "Scenario 4: Space in Incorrect Place" << endl;
		return valid;
	}
	
	// Check That First Char After Space is Digit
	tempChar = plate.at(numLetters + 1);	
	if (!isdigit(tempChar)) 
	{
		//cout << "Scenario 4: First Char After Space not Digit" << endl;
		return valid;
	} else if (numDigits == 2) 
	{
		tempChar = plate.at(numLetters + 2);
		if (!isdigit(tempChar)) {
			//cout << "Scenario 4: Second Char Ater Space Not Digit" << endl;
			return valid;
		}
	}  
		
	valid = true;
	return valid;	
}// End is Valid Function
			
// Hash:
// Given a specialized Illinois license plate, returns an index into
// the underyling hash table.  If the given plate does not follow the
// formatting rules given below, -1 is returned.
//
// Personalized:
//   letters and numbers, with a space between the letters 
//   and numbers.  Format: 1-5 letters plus 1..99 *OR* 
//   6 letters plus 1..9
//
//   Examples: A 1, B 99, ZZZZZ 1, ABCDEF 3
//
// Vanity:
//   Format: 1-3 numbers *OR* 1-7 letters
// 
//   Examples: 007, 1, 42, X, AAA, ZZZEFGH
//
int ILplates::Hash(string plate)
{
  int  index = -1;
  char tempChar;
  int  tempInt; 
  unsigned int i;
	
  unsigned int numLetters = -1;
  unsigned int numDigits = -1;

  vector <int> vectorOfLetters(7);
  vector <int> vectorOfDigits;
  
  i = 0;
  numLetters = 0;
  numDigits = 0;

  for (i = 0; i < vectorOfLetters.size(); ++i)
  {
	vectorOfLetters.at(i) = -1;
  }
	
  // Check if the plate is valid.
  // If it isn't, then return -1.
  if(!isValid(plate)) {
	  //cout << "invalid" << endl; // Debugging to See That Invalids are Rejected
	  return -1;
  } 
	
  // Assuming Plate is Valid . . .
  // Determine Unconstrained Hash 
 
  // Step One: Determine Number of Digits and Letters
  for (i = 0; i < plate.size(); ++i) 
  {
	tempChar = plate.at(i);
	  
	if (isupper(tempChar)) {
		vectorOfLetters.at(numLetters) = tempChar - 65; // Subtracts ASCII Value of 'A'
		numLetters = numLetters + 1;
	}
	  
	if (isdigit(tempChar)) {
		tempInt = tempChar - 48; // Subtracts ASCII Value of '0'
		vectorOfDigits.push_back(tempInt); 
		numDigits = numDigits + 1;
	}
  } // End of Counting Number of Digits and Letters
	
  // Step Two: Hash "Digit Only" Plates and Return
  if (numLetters == 0) 
  {
	index = 0;
	  
	// Assumes First Digit Read In From File is Most Significant Digit
	if (vectorOfDigits.size() == 3) {
		index = index + vectorOfDigits.at(0)*100 + vectorOfDigits.at(1)*10 + vectorOfDigits.at(2);
	}
	
	if (vectorOfDigits.size() == 2) {
		index = index + vectorOfDigits.at(0) * 10 + vectorOfDigits.at(1);
	} 
	  
	if (vectorOfDigits.size() == 1) {
		index = index + vectorOfDigits.at(0);
	}
	  
	return index%HT.Size();
	  
  } // End Hash of Digits Only
  
  // Step Three: Hash Plates Containing ONLY Letters
  int tempValue;
  int weight;
	
  if (numDigits == 0) 
  {
	 index = 0;
	 tempValue = 0;
	 
	 for (i = 0; i < numLetters; ++i) {
		
		if(vectorOfLetters[i] > -1) {
			
			tempValue = tempValue + (vectorOfLetters[i] + 1); // Ensures that A is Accorded at Least "1"
			
		}
	} // End for loop
	
	// We Shift by 10,000 to avoid All Digit Collisions
	// We Add 700,000 to Avoid Collisions with Letters and Numbers 
    index = index + tempValue*numLetters*31;   
	  
	return index%HT.Size(); 
	  
  } // End if numDigits == 0 	
	
  // Step Four: Hash Plates Containing at Least One Letter But Not Only Letters
  if ((numLetters > 0) && (numDigits > 0)) 
  {
	index = 0;
	tempValue = 0;
	weight = 0;
	  
	// Hundred Thousandths Place, Ten Thousandths, One Thousandths	  
	for (i = 0; i < numLetters; ++i) {
		
		if (i == 0) {
			weight = 1;
		} else if (i == 1) {
			weight = 3;
		} else if (i == 2) {
			weight = 5;
		} else if (i == 3) {
			weight = 7;
		} else if (i == 4) {
			weight = 11;
		} else if (i == 5) {
			weight = 13;
		} else {
			weight = 17;
		}
		
		if(vectorOfLetters[i] > -1) {
			
			// We Add 1 to VectorOfLetters To Ensure A is Accorded Value of 1 
			tempValue = tempValue + (vectorOfLetters[i]+1)*weight; 
			
		}
	} // This Generates a Number Between 0 and 700  
	  
	index = index + tempValue*(numLetters+numDigits)*983;  
	  
	// Add any Digits (1-999)  
	// Assumes Last Digit is Most Significant Digit
	tempValue = 0;
	  
	if (vectorOfDigits.size() == 3) {
		tempValue = vectorOfDigits.at(0)*100 + vectorOfDigits.at(1)*10 + vectorOfDigits.at(2);
	}
	
	if (vectorOfDigits.size() == 2) {
		tempValue = vectorOfDigits.at(0) * 10 + vectorOfDigits.at(1);
	} 
	  
	if (vectorOfDigits.size() == 1) {
		tempValue =  vectorOfDigits.at(0);
	}
	
	index = index + tempValue;
  }
  
  // Debugging:  The Following Line is For Debugging Only	
  // cout << "index : " << index << "index / HTSize : " << index % HT.Size() << endl;
	
  return index % HT.Size();
}
		
// Search: 
// Hashes and searches for the given license plate; returns the 
// associated value for this plate if found, or -1 if not found.
int ILplates::Search(string plate)
{
  // Declare Relevant Variables
  int hashedIndex;
  int newIndex;
  bool empty;
  string key;
  int value;
  int endOfArray;
  bool wrap;
	
  // Set Wrap to False
  wrap = false;
 	
  // Step One: Get the Hash Index of the Plate
  // Passed To the Function
  hashedIndex = Hash(plate);
  
  // Step Two: Get the Relevant Information
  // from Hashtable Using Get Function	
  HT.Get(hashedIndex, empty, key, value);
  //cout << "Outside Search : " << plate << endl;
  
  // If Element is Empty
  // Then That Should Mean It Does not Exist
  // Because When It was Inserted, It Should Have Been
  // Inserted at this Location UNLESS there was Another Item
  // Already In There	
  if (empty) {
	  return -1;
  }	
	
  // If Element not Empty
  // Check if Key == Plate
  if (key == plate) {
	return value;
  }
  	
  newIndex = hashedIndex;
  endOfArray = HT.Size() - 1;
  
  newIndex = newIndex + 1;
	
  while (!empty) {
	  
	  // Check if We have Reached
	  // the End of the Array
	  if (newIndex > endOfArray) {
		  newIndex = 0;
		  wrap = true;
	  }
	  
	  // If We have Wrapped Around
	  // and newIndex is Back to HashedIndex then
	  // Return -1 not Found
	  if (wrap) {
		  if (newIndex == hashedIndex) {
		  return -1; 
		  }
	  }

	  // At This Point We Know the New Index is
	  // not Out of Range and We Have not Traversed
	  // the entire Index yet
	  HT.Get(newIndex, empty, key, value);
      //cout << "Probe inside Search: " << plate << endl; 
		  
	  if (empty) {
		  return -1;
	  }
	  
	  if (key == plate) {
		  return value;
	  }
	 
	newIndex = newIndex + 1;
		  
  } // End while 
  	
  return -1;
}

// Insert:
// Inserts the given (plate, newValue) into the hash table,
// overwriting an existing value if there.
//
void ILplates::Insert(string plate, int newValue)
{
  // Declare Relevant Variables
  int hashedIndex;
  string key;
  int value;
  int newIndex;
  bool empty;
  int endOfArray;
  bool wrap;
	
  // Initialize Wrap to False
  wrap = false;
	  
  // Step One: Find the Relevant Hashed Index Value
  hashedIndex = Hash(plate);
 
  // Step Two: 
  // Get Relevant Values at HashedIndex
  HT.Get(hashedIndex, empty, key, value);
  newIndex = hashedIndex;
  endOfArray = HT.Size() - 1;
  
  // Step Three A or B: 
  // If The Position in the HashedIndex is Empty
  // Insert Value into Empty Position and Return
  // If it is NOT Empty, but the key == plate,
  // then insert and return
  if (empty) {
	  HT.Set(hashedIndex, plate, newValue);
	  return;
  }
  
  if (key == plate) {
	  HT.Set(hashedIndex, plate, newValue);
	  return; // Returns to Main 
   }
	
  //Step Four:
  //If it is not Empty, Start Linear Probing
  //If Key == Plate, then Insert Value
  //Otherwise, Wait Until You Find First Empty Position in HashTable
  
  newIndex = newIndex + 1;

  while (!empty) {  
	  
	  // Check if We have Reached
	  // the End of the Array
	  if (newIndex > endOfArray) {
		  newIndex = 0;
		  wrap = true;
	  }
	  
	  // If We have Wrapped Around
	  // and newIndex is Back to HashedIndex then
	  // Break While Loop and Return 
	  if (wrap) {
		  if (newIndex == hashedIndex) {
			  return; // Returns to Main
		  }
	  }
	  
	  // We Know That newIndex is Valid
	  // Not Past End of Array
	  // Not Past Original HashedIndex

	  // So Get a New Set of Values from Hashtable
	  HT.Get(newIndex, empty, key, value);
	  // cout << "Insert Inside : " << plate << " " << Hash(plate) << endl;	  
	 
	  // key == plate
	  // Insert New 
	  if (key == plate) {
		  HT.Set(newIndex, plate, newValue);
		  return; // Returns to Main 
	  }
	  
	  // If it is Empty, then insert
	  if (empty) {
		  HT.Set(newIndex, plate, newValue);
		  return; // Returns to Main
	  }
	  
	  newIndex = newIndex + 1;
	  
  } // end while loop
  	
} // end Insert function
